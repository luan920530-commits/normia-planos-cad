# Formato de plano (esquema v4)

Normia Planos CAD guarda cada piso como un documento JSON normalizado. El mismo documento se usa en la base de datos (`floors.design_json` y `floor_versions.design_json`), en la API del editor y en las exportaciones.

## Documento raíz

```json
{
  "format": 2,
  "canvas": {
    "width": 1123,
    "height": 794,
    "grid": 20,
    "unit": "cm",
    "scale": "1:100",
    "background": "#ffffff",
    "occupancy": 40
  },
  "layers": [
    { "id": "capa_planta", "name": "Planta", "visible": true, "locked": false },
    { "id": "capa_senalizacion", "name": "Señalización", "visible": true, "locked": false }
  ],
  "elements": [],
  "groups": [],
  "extinguishers": { "profile": "colombia", "hazard": "ordinary" }
}
```

| Campo | Tipo | Reglas |
| --- | --- | --- |
| `format` | entero | `2` cuando ningún trazo lleva curvas (idéntico a la 1.10.0) y `3` cuando al menos uno trae `curves`. Cualquier otro valor se rechaza con `422`. |
| `canvas.width` / `canvas.height` | entero | 400–4000 / 300–3000. |
| `canvas.grid` | entero | 5–100. |
| `canvas.unit` | texto | `cm`, `m` o `mm`. |
| `canvas.scale` | texto | `1:<1–99999>`. Es una referencia declarada. |
| `canvas.background` | color | `#ffffff` o `#f8fafc`. |
| `canvas.occupancy` | entero | 0–10 000 personas. `0` (o ausente) = sin declarar: el auditor estima la ocupación por superficie y lo advierte. |
| `layers` | arreglo | 1–24 capas; la primera es la capa inicial. |
| `elements` | arreglo | 0–1200 elementos. |
| `groups` | arreglo | 0–80 grupos con 2–80 miembros existentes. |
| `extinguishers` | objeto | Opcional. `profile`: `colombia` (por defecto) o `nfpa10`; `hazard`: `light`, `ordinary` (por defecto) o `extra`. Si falta, se aplica el perfil colombiano con riesgo ordinario. |

### Capas

```json
{ "id": "capa_equipos", "name": "Equipos", "visible": true, "locked": false }
```

- `id`: identificador estable, no vacío, sin límite estricto más allá de ser único en el piso.
- `name`: hasta 60 caracteres; se escapa al mostrarse.
- `visible: false` impide seleccionar y editar sus elementos.
- `locked: true` impide mover, borrar o modificar; bloquea también el cambio de capa.
- No se puede eliminar la última capa. Al eliminar una capa, sus elementos pasan a la primera capa restante.

`isExit` solo se conserva en `door`, `door_double` y `door_garage`; el validador rechaza con `422` cualquier otro valor que no sea booleano y elimina la marca de los demás tipos. Es la referencia que usa el auditor para medir el recorrido de evacuación.

## Elementos

Todos los elementos comparten:

| Campo | Tipo | Notas |
| --- | --- | --- |
| `id` | texto | `^[A-Za-z][A-Za-z0-9_-]{2,63}$`, único en el piso. |
| `type` | texto | Debe existir en el catálogo o ser una forma básica. |
| `layerId` | texto | Debe existir en `layers`. |
| `x`, `y` | número | Esquina superior izquierda de la caja, dentro del lienzo. |
| `w`, `h` | número | ≥ 2; no puede exceder el lienzo desde `x`/`y`. |
| `rotation` | número | 0–359. |
| `color` | color | Uno de los 29 de la paleta (las señales ISO usan el color de su familia). |
| `stroke` | número | 0–40. |
| `opacity` | número | 0.1–1. |
| `label` | texto | Hasta 240 caracteres, máximo 6 líneas, sin `<` ni `>`. |
| `locked` | booleano | Bloquea la edición de ese elemento. |

### Formas básicas

| `type` | Geometría | Campos propios |
| --- | --- | --- |
| `wall` | Trazo | `points` (2–40), `stroke` grueso. |
| `door` | Puerta de un batiente (90 × 90 por defecto) | `flipX` y `flipY` para cambiar el sentido de apertura; `isExit` para marcarla como salida de emergencia. |
| `door_double` | Puerta de dos batientes (120 × 60) | `flipX`, `flipY` e `isExit`. |
| `door_garage` | Portón o reja de garaje (160 × 50) | `flipX`, `flipY` e `isExit`. |
| `route` | Ruta de evacuación | `points` (2–40), flechas. Un circuito cerrado repite el primer punto al final. |
| `text` | Texto | `fontSize` 8–160, `label` obligatoria. |
| `dimension` | Medida | `points` exactamente 2; `label` opcional. |
| `line` | Línea | `points` exactamente 2. |
| `rect` | Rectángulo | — |
| `ellipse` | Elipse | — |
| `pipe` | Tubería hidrosanitaria, de gas o de incendio | `network`, `diameter`, `material`, `slope` (0–15 %), `pressure` (0–5000 kPa) y `points` (2–40). |
| `conduit` | Tubería eléctrica de un circuito | `circuit` (1–12 caracteres `A-Z 0-9 . -`), `voltage`, `gauge`, `phases` (1 o 3) y `points` (2–40). |
| `road` | Vía vehicular esquemática | `widthM` (0,8–30 m), `lanes` (1–6) y `points` (2–40). No bloquea el tránsito; cuenta como exterior. |
| `sidewalk` | Andén esquemático | `widthM` (0,8–30 m) y `points` (2–40). Cuenta como exterior. |
| `crosswalk` | Paso cebra | Caja; cuenta como exterior. |
| `parking` | Parqueadero con puestos de 2,50 × 5,00 m | Caja; cuenta como exterior. La etiqueta indica cuántos puestos caben. |
| `property` | Límite de predio (línea y punto) | `points` (2–40); cuenta como exterior. |

Los tipos con trazo guardan `points` **en coordenadas locales** a la caja (`0..w`, `0..h`). Mover o escalar la caja transforma el trazo de forma proporcional.

### Trazos con curvas (formato 3)

Los tipos `wall`, `route`, `line`, `pipe`, `conduit`, `road`, `sidewalk` y
`property` admiten **arcos de tres puntos**:

```json
{
  "points": [{ "x": 0, "y": 100 }, { "x": 240, "y": 100 }],
  "curves": [{ "kind": "arc", "through": { "x": 120, "y": 0 } }, null]
}
```

| Regla | Detalle |
| --- | --- |
| Alineación | `curves` tiene exactamente el mismo largo que `points`; `curves[i]` describe el tramo `points[i] → points[i+1]` y el último hueco es `null`. |
| Contenido | Solo `{ "kind": "arc", "through": { "x", "y" } }` o `null`. `through` va en coordenadas locales, como los vértices. |
| Tipos | Curvas en un tipo que no es de trazo → `422`. `kind` distinto de `arc` → `422`. Arreglo desalineado → `422`. |
| Recto | Si `through` es colineal con el tramo, la curva se normaliza a `null`; sin ninguna curva el documento queda en `format: 2`. |
| SVG | Con curvas el exportador escribe `<path d="M … A r r 0 large sweep x y">`; sin curvas sigue escribiendo `<polyline>`, idéntico al de la 1.10.0. |
| Aplanado | Tolerancia compartida cliente/servidor: 0,5 cm en `cm`, 0,005 m en `m` y 5 mm en `mm`; máximo 720 cuerdas por arco. |

Los detalles de dibujo, límites y degradación están en
[`docs/MUROS_Y_VIAAS.md`](MUROS_Y_VIAAS.md).

### Sección tipo y cruces de la vía (formato 4)

Una vía puede llevar su **sección tipo** en metros. Con `section` el documento
pasa a `format: 4`; sin ella sigue siendo v2 o v3 y se dibuja igual que antes.

```json
{
  "type": "road",
  "widthM": 20,
  "lanes": 4,
  "section": { "lanes": 4, "laneM": 3.25, "medianM": 2, "shoulderM": 0.5, "bikeM": 0, "sidewalkM": 2 },
  "junction": { "kind": "roundabout", "legs": 4, "islandM": 6 }
}
```

| Campo | Límites | Qué hace |
| --- | --- | --- |
| `lanes` | 1–6 | Carriles de la calzada; define las líneas discontinuas y las flechas. |
| `laneM` | 2,5–4 m | Ancho de cada carril. |
| `medianM` | 0–4 m | Separador central con doble línea; en 0 el eje va discontinuo. |
| `shoulderM` | 0–2 m | Berma a cada lado, dibujada como línea interior. |
| `bikeM` | 0–3 m | Ciclorruta a cada lado, pegada al bordillo. |
| `sidewalkM` | 0–4 m | Andén a cada lado, fuera de la calzada. |
| `junction.kind` | `roundabout`, `tee`, `cross` | Glorieta o intersección; exige `section`. |
| `junction.legs` | 3–5 | Accesos de la glorieta (T = 3, cruz = 4 fijos). |
| `junction.islandM` | 1–40 m | Radio de la isla de la glorieta. |

| Regla | Detalle |
| --- | --- |
| Ancho derivado | `widthM = lanes·laneM + medianM + 2·shoulderM + 2·bikeM + 2·sidewalkM`; el servidor lo recalcula y descarta el ancho enviado. |
| Límites | `widthM` de una vía con sección llega a **46 m**; un andén suelto sigue en 30 m. |
| Validación | Clave desconocida en `section` o `junction` → `422`. Medida fuera de rango → `422`. `junction` sin `section` → `422`. `kind` desconocido → `422`. |
| Dibujo | Calzada blanca con bordes de color, líneas discontinuas entre carriles, separador con doble línea o eje discontinuo, flechas de sentido opuesto por calzada y rótulo «N carriles · X,X m». |
| Glorieta | Anillo con isla, líneas de carril en arco y brazos recortados al marco; la caja del elemento fija el tamaño (cuadrada). |
| Intersección | Unión de calzadas con líneas de carril, cebras y rótulo de accesos. |
| Exportación | `SvgExporter::roadSectionMarkup()` y `roadJunctionMarkup()` reproducen el mismo dibujo, en coordenadas absolutas. |
| Compatibilidad | Un plano v2/v3 se abre igual; solo al guardar una vía con `section` sube a `format: 4`. |

### Señales y equipos

- Señales ISO 7010: `iso_<código en minúsculas>`, por ejemplo `iso_e002` (salida de emergencia) o `iso_f001` (extintor). Se validan contra `resources/iso7010-catalog.json`.
- Señales de orientación y servicios: `sig_<nombre>` → `SVC_<NOMBRE>`, por ejemplo `sig_wc_men` (baño de hombres) o `sig_cafeteria`. Se validan contra `resources/service-signs.json`; son complementarias, no ISO 7010.
- Equipos: clave del catálogo `cad_*`, por ejemplo `cad_desk` o `cad_stairs_straight`. Se validan contra `resources/cad-objects.json`.
- Ambos se dibujan insertando el SVG del catálogo como símbolo saneado, con tamaño cuadrado por defecto (la señal mide 64×64 unidades por defecto).
- Los trazos (`wall`, `route`, `line`, `dimension`) guardan `points` en coordenadas locales. Al editar un vértice el cliente reescribe la caja (`x`, `y`, `w`, `h`) con los límites reales y **disuelve la rotación en los puntos**, de modo que el servidor sigue recibiendo un documento válido sin cambios de esquema.
- El catálogo de equipos tiene 420 objetos en 31 familias (`furniture`, `sanitary`, `kitchen`, `industrial`, `vehicles`, `vertical`, `restaurant`, `warehouse`, `retail`, `hospital`, `textile`, `grill`, `supermarket`, `residential`, `sports`, `outdoor`, `electrico`, `hidraulico`, `eds`, `drogueria`, `gimnasio`, `colegio`, `cafeteria`, `fire`, `emergency`, `technic`, `access`, `security`, `road`, `traffic-signs`, `bikes`). Algunos objetos traen su propio `color` (por ejemplo el agua de piscinas, `#0891b2`); el resto hereda el color del elemento.
- Los objetos de la familia `electrico` admiten además `circuit` y `load` (VA), y el editor los suma al cálculo del circuito.

### Extintores

Los cuatro equipos de extinción del catálogo —`cad_eds_extinguisher`, `cad_drg_extinguisher`, `cad_fire_ext_co2` y `cad_fire_ext_wheeled`— admiten datos de norma:

```json
{ "id": "ext_abc_01", "type": "cad_eds_extinguisher", "layerId": "capa_seguridad",
  "x": 120, "y": 120, "w": 44, "h": 44, "rotation": 0, "color": "#b71f2e", "stroke": 2,
  "opacity": 1, "label": "ABC 20 lb", "locked": false,
  "extAgent": "pqs_abc", "extCapacityLb": 20, "extRating": "4-A:60-B:C",
  "extHazard": "ordinary", "extMountCm": 110 }
```

| Campo | Tipo | Reglas |
| --- | --- | --- |
| `extAgent` | texto | Clave de `agents` en `resources/extinguisher-criteria.json`: `pqs_abc`, `pqs_bc`, `co2`, `water`, `foam`, `wet_k` o `d_powder`. Un valor fuera del catálogo devuelve `422`. |
| `extCapacityLb` | número | 1–400 lb. Es la capacidad nominal declarada, no el peso bruto. |
| `extRating` | texto | Clasificación normalizada en mayúsculas: `2-A:10-B:C`, `10-B:C`, `4-A:80-B:C`, `1-A:K`, `D`. El servidor rechaza cualquier otra forma. |
| `extHazard` | texto | `light`, `ordinary` o `extra`. Ajusta el mínimo y el área admisible de este equipo. |
| `extMountCm` | número | 0–300 cm desde el piso hasta la parte superior. `0` = rodante o apoyado en el piso. |

- Los campos `ext*` solo se aceptan en estos cuatro tipos; en cualquier otro, el validador responde `422`.
- Si el elemento guardado no trae los campos, el servidor los completa con `catalogDefaults` (referencia de fabricante) para que el cálculo sea posible. Esos valores son revisables y **no** son un dato de norma: la clasificación real está en la placa del equipo.
- El perfil y el riesgo del documento (`extinguishers`) definen las tablas del cálculo; el riesgo del elemento puede sobrescribirlo para un equipo concreto.

### Redes técnicas (`pipe` y `conduit`)

```json
{ "id": "el_agua_1", "type": "pipe", "layerId": "capa_hidraulica", "x": 700, "y": 300, "w": 400, "h": 100, "rotation": 0,
  "color": "#0891b2", "stroke": 3.5, "opacity": 1, "label": "", "locked": false,
  "network": "agua_fria", "diameter": "3/4\"", "material": "pvc", "slope": 0, "pressure": 280,
  "points": [{ "x": 0, "y": 0 }, { "x": 400, "y": 100 }] }
```

- `network` pertenece a `resources/mep-networks.json`: `agua_fria`, `agua_caliente`, `gas`, `aguas_negras`, `aguas_lluvias`, `incendio`.
- `diameter` debe existir en `diameters`; `material`, en `materials`. Si la red es de gravedad (`aguas_negras`, `aguas_lluvias`), `slope` es la pendiente física declarada en % y se compara con `slopes` para avisar.
- `conduit` guarda `circuit`, `voltage` (de `electrical.voltages`), `gauge` (de `electrical.gauges`) y `phases`.
- El servidor **rechaza** redes, diámetros, materiales, tensiones, calibres o fases fuera del catálogo; los elementos que no son de red no pueden traer estos campos.
- La API `GET …/api/floors/{id}/mep` devuelve el resumen calculado (longitudes, cargas, breaker, calibre, caída de tensión) del último diseño guardado.

### Grupos

```json
{ "id": "grupo_puesto", "name": "Puesto de trabajo", "members": ["el_escritorio", "el_silla"] }
```

Los grupos no anidan. Al eliminar miembros, el grupo se disuelve si queda con menos de 2. Al agrupar se expanden los grupos previos para evitar anidamiento.

## Envoltura de exportación

`GET …/export/json` devuelve:

```json
{
  "application": "normia-planos-cad",
  "format": "normia-plan",
  "schema_version": 2,
  "exported_at": "2026-01-01T12:00:00+00:00",
  "project": { "name": "...", "site": "...", "workplace": "...", "responsible": "...", "notes": "..." },
  "floor": { "name": "Planta baja", "level": "Nivel 0" },
  "design": { "format": 2, "canvas": {}, "layers": [], "elements": [], "groups": [] },
  "attribution": "Normia Planos CAD · GPL-3.0 · pictogramas ISO 7010 con licencia MIT (ver NOTICE)"
}
```

La importación desde el editor acepta esta misma envoltura (usa `design`) y también un documento de diseño suelto.

## Importación heredada (formato 1)

La versión de referencia exportaba un JSON plano:

```json
{
  "format": 1,
  "tool": "wall",
  "elements": [
    { "id": "muro_1", "tool": "wall", "x": 10, "y": 20, "w": 200, "h": 10, "points": [{"x":0,"y":5},{"x":200,"y":5}] },
    { "id": "senal_1", "tool": "exit", "x": 300, "y": 200, "w": 64, "h": 64 },
    { "id": "ruta_1", "tool": "route", "x": 100, "y": 100, "w": 400, "h": 300, "points": [{"x":0,"y":0},{"x":400,"y":300}] }
  ]
}
```

Reglas de conversión:

| Heredado | Se convierte en |
| --- | --- |
| `tool: "wall"` | `type: "wall"` con `points` |
| `tool: "door"` | `type: "door"` |
| `tool: "route"` / `"path"` | `type: "route"` |
| `tool: "text"` | `type: "text"` |
| `tool: "measure"` / `"dimension"` | `type: "dimension"` |
| `tool: "line"`, `"rect"`, `"ellipse"` | mismo tipo |
| `exit`, `exit_sign`, `emergency_exit` | `iso_e002` |
| `extinguisher`, `fire_extinguisher` | `iso_f001` |
| `first_aid`, `first_aid_kit` | `iso_e003` |
| `alarm` | `iso_f005` |
| `assembly` | `iso_e007` |

Alias y equivalencias viven en `resources/sign-aliases.json`. Un archivo con cualquier herramienta desconocida, coordenada no finita, color fuera de la paleta, punto fuera de su caja o markup en etiquetas se rechaza **completo**: la importación es atómica.

## Saneado de los SVG de las bibliotecas

Los SVG de señalización y equipamiento se validan al cargar los catálogos. Se rechaza el catálogo si un SVG contiene `<script>`, `<foreignObject>`, `<iframe>`, `<object>`, `<embed>`, `<audio>`, `<video>`, `<image>`, `<style>`, atributos `on*`, `href`/`xlink:href` que no empiecen por `#`, `javascript:`/`vbscript:`/`data:`, `url()` remotos, `<!ENTITY`, `<!DOCTYPE` o `xml-stylesheet`.

Al exportar, los símbolos se incrustan con identificadores únicos por plano y sin referencias externas. La aplicación **no importa** SVG suministrados por el usuario: la importación de planos es solo JSON.

## Compatibilidad

- El editor normaliza siempre al cargar y elige el formato de salida: `4` si alguna vía lleva sección tipo, `3` si algún trazo conserva curvas y `2` si no. Descarta tipos desconocidos y recorta valores fuera de rango.
- Los planos **v2** se abren sin cambios. Un plano **v3** abierto en la 1.10.0 se ve con los tramos rectos porque esa versión ignora `curves` y normaliza a `format: 2`.
- Los documentos guardados con el esquema actual no se modifican al exportar; el JSON es una copia íntegra del diseño normalizado.
- La API acepta `format` 2, 3 y 4; el resto responde `422`. `schema_version: 2` de la envoltura de exportación describe el sobre, no la versión del diseño.
- Si en el futuro cambia el esquema, `schema_version` permitirá migraciones explícitas.
