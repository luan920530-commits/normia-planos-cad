import fs from 'node:fs';
import { Resvg } from '@resvg/resvg-js';
const php = fs.readFileSync('app/Views/partials/icons.php','utf8').split('?>')[1];
const sym = id => [...php.matchAll(/<symbol id="(i-[a-z0-9-]+)"[^>]*>([\s\S]*?)<\/symbol>/g)].find(m=>m[1]===id)[2];
const items = [['select','Seleccionar',1],['hand','Mano',0],['wall','Muro',0],['door','Puertas',0,1],['route','Ruta',0],['pipe','Tubería',0,1],['sign','Señales',0,2,'62'],['cad','Equipos',0,2,'145']];
const S=4, W=80, H=items.length*54+24;
let out = `<svg xmlns="http://www.w3.org/2000/svg" width="${W*S}" height="${H*S}" viewBox="0 0 ${W} ${H}">
<defs>
  <linearGradient id="rail" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#0d1728"/><stop offset="1" stop-color="#0a1220"/></linearGradient>
  <linearGradient id="chip" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity=".11"/><stop offset="1" stop-color="#ffffff" stop-opacity=".03"/></linearGradient>
  <linearGradient id="blue" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#4a97ff"/><stop offset=".46" stop-color="#0a6cf5"/><stop offset="1" stop-color="#0a55cc"/></linearGradient>
  <linearGradient id="lib" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#6fb2ff"/><stop offset=".46" stop-color="#2c7cf0"/><stop offset="1" stop-color="#1b5fce"/></linearGradient>
</defs>
<rect width="${W}" height="${H}" fill="url(#rail)"/>`;
items.forEach(([id,label,active,caret,count],i)=>{
  const cy = 12 + i*54;
  const bx = 7, bw = 66, cx = bx + bw/2;
  out += `<circle cx="${cx}" cy="${cy+18}" r="0" />`;
  // chip
  out += `<rect x="${cx-18}" y="${cy}" width="36" height="36" rx="12" fill="url(#${active?'blue':'chip'})" stroke="#fff" stroke-opacity="${active?'.34':'.085'}"/>`;
  out += `<g transform="translate(${cx-10} ${cy+8})" fill="none" color="#fff" stroke="#fff" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">${sym('i-'+id)}</g>`;
  out += `<text x="${cx}" y="${cy+47}" text-anchor="middle" font-family="Helvetica" font-size="9.8" font-weight="600" fill="${active?'#fff':'#a9b7cc'}">${label}</text>`;
  if (caret) out += `<circle cx="${cx+20}" cy="${cy+2}" r="8" fill="#0b1424" stroke="#fff" stroke-opacity=".3"/><g transform="translate(${cx+15} ${cy-3})" fill="none" color="#cdd9ea" stroke="#cdd9ea" stroke-width="2" stroke-linecap="round">${sym('i-chevron-down')}</g>`;
  if (count) out += `<rect x="${cx+5}" y="${cy-2}" width="${count.length*5+8}" height="13" rx="6.5" fill="#fff" fill-opacity=".22" stroke="#fff" stroke-opacity=".22"/><text x="${cx+9}" y="${cy+7.5}" font-family="Helvetica" font-size="7.5" font-weight="700" fill="#fff">${count}</text>`;
});
out += '</svg>';
fs.writeFileSync('_mock.png', new Resvg(out).render().asPng());
console.log('ok');
