# Auditoría técnica · Normia Planos CAD 1.16.0

| | |
|---|---|
| **Versión auditada** | 1.16.0 (`NORMA_VERSION`, `package.json`, `package-lock.json`) |
| **Commit base** | `31f2ed0` (`main`), entrega de complementos · PR #50 |
| **Fecha** | 1 de noviembre de 2026 |
| **Alcance** | Lectura de código, esquema, catálogos, pruebas y documentación. Sin cambios, sin commits, sin escrituras en base de datos. |
| **Método** | Inspección estática del repositorio + `curl` de solo lectura contra la vista previa local (`0.0.0.0:8080`) |
| **Resultado** | 32 hallazgos: **2 P0**, **10 P1**, **13 P2**, **7 P3**. No se encontraron vulnerabilidades de ejecución remota ni claves de servicio en el repositorio (`config/config.php` está en `.gitignore`; solo se versiona `config.example.php`). La única credencial embebida es la cuenta de fábrica del APK (H-32). |

> **Cómo leer este documento.** Cada hallazgo trae **dónde** (archivo, clase, método o tabla), **qué pasa**, **consecuencia** y **recomendación**. Lo que no se pudo comprobar está marcado como **«no verificado»** y se reagrupa en el Anexo B. Ninguna afirmación de cumplimiento normativo se hace aquí: la aplicación lo evita a propósito y esta auditoría mantiene ese criterio.

---

## 1. Resumen ejecutivo

Normia Planos CAD es una aplicación **PHP 8.1+ sin framework** (MVC propio, ~11 250 líneas PHP sin contar las vistas) con un **editor CAD en JavaScript sin dependencias** (~11 850 líneas) que dibuja planos de emergencia y evacuación en SVG y los guarda en **una base SQLite por instalación**. Es un producto **monoinstalación y monousuario** que hoy funciona de punta a punta: instalar, crear proyecto y pisos, dibujar, medir rutas, calcular cobertura de extintores con dos perfiles normativos, auditar la geometría, verificar en campo con evidencia fotográfica, publicar un enlace de solo lectura para la brigada y exportar SVG/JSON/impresión.

**Lo que está bien hecho, y conviene no tocar:**

- **Autorización por consulta, no por pantalla.** Todo controlador que toca un plano pasa por `BaseController::project()`/`floor()`, que resuelven con `Project::findForUser` y `Floor::findForUser`; y las escrituras críticas vuelven a filtrar por `projects.user_id` en su propio SQL (`Floor::saveDesign`, `Floor::restoreVersion`, `Check::photo`). No hay rutas que confíen en el id que llega por la URL. La única vía sin sesión es la del modo brigadista, y es de solo lectura por diseño.
- **Endurecimiento web correcto para un producto sin CDN:** CSP con `script-src 'self'`, `X-Frame-Options: DENY`, `nosniff`, `Referrer-Policy`, cookies `HttpOnly` + `SameSite=Lax` + `Secure` cuando hay HTTPS, `session.use_strict_mode`, regeneración de sesión al autenticar y verificación de contraseña contra un hash señuelo cuando el usuario no existe (evita enumeración por tiempo).
- **Validación de dominio centralizada y con límites duros** (`DesignValidator`): lista blanca de tipos, paleta cerrada, topes de elementos, capas, grupos y puntos, y saneado de etiquetas que descarta `<`, `>`, `javascript:`, `vbscript:` y `data:`.
- **Conflicto de guardado resuelto con producto, no con un error:** el 409 `version_conflict` se muestra como aviso con «Recargar» y «Descargar copia local» (`editor.js:1874`, `1944`).
- **Verificación automatizada densa para un proyecto sin framework:** 15 pasos, 310 comprobaciones funcionales en PHP 8.1 y 8.3, 383 del editor, 50 de páginas, 39 de paquete, 37 de escritorio, 52 de Android, 40 de Electron, 124 de funcionamiento sin red.

**Lo que impide ampliarla hoy, en una frase:** la aplicación está construida sobre la hipótesis «una instalación = un usuario = sus planos», y **no existe ninguna entidad que represente organización, sede, activo, brigada ni acción**, de modo que cada módulo nuevo del sistema de gestión tendría que inventar su propio modelo de propiedad de datos.

**Los dos P0** son de integridad, no de intrusión: no hay respaldo automático ni verificación de integridad de la base (un archivo `.sqlite` contiene planos, versiones y fotos), y las migraciones de esquema se ejecutan en cada petición **tragándose cualquier excepción**, de modo que un fallo deja la instalación con esquema viejo funcionando a medias y sin aviso.

**Veredicto.** Como aplicación de escritorio/web para un profesional que dibuja y audita sus propios planos: **sólida y utilizable**. Como plataforma multiempresa con brigadas, incidentes, acciones correctivas y gestión química: **no preparada**, y no por falta de pantallas, sino por falta de modelo de datos. El orden correcto no es añadir módulos sino **resolver identidad y tenencia, acciones correctivas, escala física del plano, gobierno de la persistencia e inventario de recursos** (sección 11).

---

## 2. Arquitectura y tecnologías

### 2.1 Forma del sistema

```
navegador / WebView / Electron
   ├── assets/js  (editor SVG, sin framework; 23 archivos, 11 851 líneas)
   └── HTTP ──► index.php ──► Application::run()
                              ├── securityHeaders() · Session::start() · Csrf
                              ├── Config::isInstalled()  → si no: InstallController
                              ├── Database::migrate()    → en CADA petición
                              ├── Router (patrones con tipos: int, slug, word, token)
                              └── Controller ──► Service ──► Model ──► SQLite (PDO)
                                                    └── View (PHP plano + partials/icons.php)
```

- **Sin dependencias de ejecución.** No hay `composer.json`, ni `vendor/`, ni framework: autoloader propio en `bootstrap.php`. Tampoco hay CDN: todos los activos son locales, condición explícita del producto.
- **Sin build para el servidor.** El PHP se sirve tal cual; los paquetes se arman con `tools/build-packages.sh`.
- **Tres modos de ejecución del mismo código:** hosting PHP clásico, escritorio (PHP embebido + `tools/desktop/router.php`), y Android (php-wasm dentro del WebView, con `storage/` en OPFS).
- **Un solo punto de entrada** (`index.php`) y un `.htaccess` que bloquea `app|config|resources|storage|tests|tools|docs`.

### 2.2 Volumen y reparto

| Capa | Archivos | Líneas | Nota |
|---|---:|---:|---|
| `app/Core` | 15 | 1 353 | Application, Router, Request, Response, Database, Session, Auth, Csrf, View, Config, Url, Paths… |
| `app/Controllers` | 14 | 1 557 | El mayor: `VerificationController` 194 |
| `app/Models` | 5 | 940 | `Project` 284, `Check` 225, `Floor` 219 |
| `app/Services` | 17 | **7 246** | `SvgExporter` 1 040, `ExtinguisherCoverage` 936, `DesignValidator` 868, `PlanAudit` 806 |
| `app/Support` | 1 | 155 | helpers (`e`, `url`, `text_limit`, `short_date`…) |
| `app/Views` | 23 | 2 607 | PHP plano, sin motor de plantillas |
| `assets/js` | 23 | **11 851** | `editor.js` 2 586, `lib/model.js` 2 077, `lib/renderer.js` 1 488 |
| `assets/css` | 7 | — | `app.css`, `editor.css`, `print.css`, `audit.css`, `brigade.css`, `verifications.css`, `presentacion.css` |
| `tests` | 34 `.mjs` | — | 15 pasos en `run-all.mjs` |
| `resources` | 10 JSON + 1 SQL | — | `iso7010-catalog.json` 1,4 MB (332 señales), `cad-objects.json` 376 KB (420 objetos) |

Total PHP en el repositorio: **80 archivos**; JS: **27** (23 de `assets`, 4 de herramientas Android).

### 2.3 Decisiones estructurales que condicionan todo lo demás

| Decisión | Dónde | Efecto |
|---|---|---|
| El diseño del piso es **un JSON completo** en una columna (`floors.design_json`) | `resources/schema.sql` | Guardar = reescribir todo; versionar = copiar todo; no hay consultas por elemento desde SQL |
| El **lector único de bibliotecas** es `LibraryRepository` | `loadSigns`, `loadCad`, `allowedTypes`, `typeForCode`, `codeForType`, `safeSvg` | Bien resuelto; 7 consumidores lo usan, incluido el cálculo de extintores y el auditor |
| **Sin roles**: la propiedad es `projects.user_id` | todas las consultas | Simple y seguro hoy; es el muro para multiempresa |
| **SVG generado en servidor** para exportar y en cliente para editar | `SvgExporter` / `lib/renderer.js` | Dos renderizadores que deben coincidir; no hay prueba de equivalencia entre ambos (H-29) |
| **php-wasm** en escritorio y Android | `tools/desktop`, `tools/android/web` | Sin extensiones nativas (no GD, no ZIP): ya obligó a detectar imágenes por *magic bytes* (`Check::detectType`) |

---

## 3. Inventario funcional y estado real

Criterio de estado: **Operativo** = usa datos reales, tiene validación en servidor y pruebas; **Operativo con reservas** = funciona pero con un límite conocido relevante; **Parcial** = cubre una parte del flujo; **Solo presentación** = existe la pantalla y no hay operación detrás; **Ausente** = no existe.

| # | Módulo | Qué hace hoy | Estado | Evidencia | Límite conocido |
|---|---|---|---|---|---|
| 1 | Portada pública | Presentación del producto con capturas de la demo; sin registro | Operativo | `HomeController::index`, ruta `inicio`; `/` sin sesión la sirve (`Application.php:71-79`) | No hay registro: las cuentas las crea el instalador |
| 2 | Instalador | Crea base, admin y datos de ejemplo opcionales | Operativo | `InstallController`, `Services/Installer.php`, `DemoSeeder` | Una sola vez por instalación; sin asistente de migración |
| 3 | Acceso | Login con correo y contraseña, bloqueo de 6 intentos por sesión | Operativo con reservas | `Auth::attempt` | El bloqueo vive en la sesión (H-01) |
| 4 | Cuenta | Cambio de contraseña del usuario en sesión | Parcial | `AccountController` (49 líneas), rutas 179-180 | Sin recuperación, sin alta de usuarios, sin perfil |
| 5 | Proyectos y pisos | Alta, edición, duplicado, borrado en cascada, importación | Operativo | `ProjectController` (193), `Project.php` | Sin paginación ni búsqueda; `site`/`workplace` son texto libre |
| 6 | Editor CAD | Muros, vanos, rutas, equipos, señales, capas, grupos, cotas, MEP | Operativo | `assets/js/editor.js`, `lib/model.js`, 383 comprobaciones | Ver sección 6 |
| 7 | Bibliotecas | 332 ISO 7010 + 63 señales propias + 420 objetos CAD + redes MEP, con alias y búsqueda | Operativo | `LibraryRepository`, `resources/*.json` | `iso7010-catalog.json` pesa 1,4 MB y entra completo al cliente |
| 8 | Extintores | Cobertura geométrica, recorridos, área por clasificación, señales de ubicación, perfiles Colombia y NFPA 10 | Operativo | `ExtinguisherCoverage` (936), `ExtinguisherNorms`, `extinguisher-criteria.json` | No conoce vigencia, recarga ni número de serie del extintor real (H-31) |
| 9 | Auditar plano | Rejilla libre con muros y vanos; recorrido más largo, salidas, ancho, ocupación, señales; hallazgos con severidad; informe impreso | Operativo | `PlanAudit` (806), `audit-report.php` | Umbrales de referencia, no norma; el cálculo no está validado contra casos conocidos |
| 10 | MEP | Tubería y conduit, longitudes, perfiles de vía | Operativo | `MepCalculator` (327), `PlanGrid::visualPoints` | `$scale` no se usa (H-10) |
| 11 | Verificación en campo | Rondas abiertas/cerradas, estado por elemento (`pending`/`ok`/`issue`), nota y foto ≤512 KB, cobertura %, filtro de vencidos | Operativo con reservas | `Check.php`, `VerificationInventory`, `verifications/index.php` | Una novedad no genera acción, responsable ni plazo (H-22) |
| 12 | Modo brigadista | Enlace público por piso, PWA con service worker, grupos de ruta/extintores/reunión, datos para sincronizar | Operativo con reservas | `BrigadeController`, `brigade_links`, `assets/js/brigade.js` | Token sin caducidad ni límite de uso (H-04) |
| 13 | Exportación | SVG, JSON con `schema_version` 2 y atribución, vista de impresión, vista previa | Operativo con reservas | `ExportController`, `SvgExporter` (1 040), `PlanFooter` | El SVG no declara tamaño físico: no es medible con escalímetro (H-10) |
| 14 | Complementos | Instalar `.plugin.json` con señales y objetos CAD, activar, borrar, plantillas, manual | Operativo | `PluginManager` (664), `PluginController`, tabla `plugins` | Solo añade catálogo; no añade lógica, rutas ni campos |
| 15 | Pliego de señalización | — | **Ausente** | Sin rutas `…/signage` ni `…/signage.csv` en `Application::router()` | Bloque 6 del issue #6, pendiente de rehacer |
| 16 | Multiempresa y sedes | — | **Ausente** | 8 tablas y ninguna entidad de organización; `projects.user_id` es la única frontera | `projects.site` es una cadena |
| 17 | Recursos inventariables | — | **Ausente** | Extintores y equipos existen solo como objetos del dibujo | Sin serie, vencimiento, mantenimiento ni proveedor |
| 18 | Brigadas como entidad | — | **Ausente** | `brigade_links` es un enlace, no un equipo con personas y roles | Sin integrantes, cargos ni capacitación |
| 19 | Incidentes y acciones correctivas | — | **Ausente** | 0 coincidencias de `incidente` o `correctiva` en `app/` y `assets/`; no hay tabla de acciones | Base de todo sistema de gestión |
| 20 | Gestión química | — | **Ausente** | 0 coincidencias de `MSDS` o `quimic`; «sustancias» solo como etiqueta de plantilla (`plugins/manual.php:49`) | Sin inventario ni fichas de seguridad |

**Lo que no debe darse por hecho.** La existencia de la pantalla de verificación no convierte a la aplicación en un sistema de inspección: registra observaciones, no las gestiona. La pantalla de auditor no dictamina cumplimiento y la propia aplicación lo advierte en `audit-criteria.json` (`notice`) y en el pie del informe.

---

## 4. Base de datos y relaciones

**Motor:** SQLite vía PDO, un archivo por instalación (`storage/normia-*.sqlite`). `Database::connect()` fija `PRAGMA foreign_keys=ON`, `journal_mode=WAL`, `busy_timeout=5000`, `synchronous=NORMAL`. Esquema: **`user_version = 5`**, **8 tablas**.

### 4.1 Tablas

| Tabla | Columnas relevantes | Índices / restricciones | Para qué |
|---|---|---|---|
| `users` | `email` UNIQUE NOCASE, `password_hash`, `is_admin` | UNIQUE(email) | Cuentas. `is_admin` **no lo lee nadie** (H-05) |
| `projects` | `user_id` FK→users CASCADE, `name`, `site`, `workplace`, `responsible`, `notes` | `idx_projects_user(user_id, updated_at DESC)` | Obra o cliente de un usuario |
| `floors` | `project_id` FK, `design_json`, `version`, `draft_json`, `draft_base_version`, `draft_updated_at`, `check_days`, `sort_order` | `idx_floors_project` | Un piso = un plano completo en JSON |
| `floor_versions` | `floor_id` FK, `version`, `design_json`, `note`, `created_by` | `UNIQUE(floor_id, version)`, `idx_versions_floor` | Historial inmutable de guardados |
| `brigade_links` | `floor_id` FK **UNIQUE**, `token` UNIQUE, `enabled` | `idx_brigade_token` | Enlace público de solo lectura |
| `verification_rounds` | `floor_id` FK, `status` (`open`/`closed`), `started_by`, `closed_by`, `closed_at` | `idx_rounds_floor` | Jornada de verificación |
| `element_checks` | `floor_id`, `round_id`, `element_id` (texto), `element_type`, `sector`, `status`, `note`, **`photo` BLOB**, `photo_type`, `checked_by`, `checked_at` | `idx_checks_floor(floor_id, element_id)`, `idx_checks_round` | Verificación por elemento, con foto dentro de la base |
| `plugins` | `id` TEXT PK, `name`, `version`, `author`, `enabled`, `installed_at` | PK | Estado del complemento; el manifiesto vive en `storage/plugins/<id>/plugin.json` |

### 4.2 Relaciones

```
users 1────n projects 1────n floors 1────n floor_versions
                                 │ 1────1 brigade_links
                                 │ 1────n verification_rounds 1────n element_checks
                                 └── element_checks.floor_id (desnormalizado, sin FK compuesta)

plugins (aislada: describe catálogos en disco, no se relaciona con proyectos)
```

- **`element_checks` cuelga de dos sitios a la vez** (`floor_id` y `round_id`) sin restricción de que la ronda pertenezca al mismo piso. Hoy lo garantiza el código (`Check::record` recibe ambos), pero el esquema no lo impide.
- **H-28 · `element_id` es texto libre** sin FK y sin exportación: si se borra un elemento del plano, su historial de verificaciones queda apuntando a un id inexistente. La página de verificación lo ignora al reconstruir el inventario desde `design_json`, es decir, **el historial se conserva pero deja de verse**. Es correcto para trazabilidad, pero no hay forma de consultarlo ni de exportarlo.
- **`plugins` no se relaciona con nada**: los elementos que aporta quedan dentro de `design_json` como `cad_<plugin>_<objeto>`. Si se borra el complemento, los planos conservan el elemento pero el editor ya no sabe dibujarlo (el `<desc>`/nombre se pierde). **No verificado**: qué se ve exactamente en el editor con un complemento borrado y un plano que lo usaba.

### 4.3 Integridad y persistencia

- **Versiones sin poda:** cada guardado manual inserta un snapshot completo (`Floor::saveDesign`). Con `MAX_ELEMENTS = 1200` y JSON aceptado hasta 2,5 MB, 100 guardados pueden dejar **cientos de MB por piso** (H-13).
- **Escritura optimista:** `saveDesign` compara `version` esperada y comprueba `rowCount() === 1`; si no, lanza `VersionConflictException` → 409. **Bien.** `restoreVersion` hace el mismo `WHERE version = ?` pero **no comprueba `rowCount()`** antes de insertar la fila en `floor_versions` (H-14).
- **Transacciones:** `Database::transaction()` usa `beginTransaction()`, es decir `BEGIN` diferido. En WAL, un `SELECT` seguido de `UPDATE` dentro de la misma transacción puede fallar con `SQLITE_BUSY` si otra conexión escribió en medio. `busy_timeout=5000` lo mitiga, no lo elimina. **No verificado bajo concurrencia real.**
- **Zonas horarias mezcladas:** `updated_at` usa `CURRENT_TIMESTAMP` (UTC) y `saveDesign` devuelve `date('Y-m-d H:i:s')` (America/Bogotá). La misma respuesta trae dos horas distintas (H-15).
- **Un borrador por piso:** `draft_json` + `draft_base_version` sin autor. Con una sola persona es correcto; con dos, el segundo pisa el borrador del primero sin verlo (H-16).

---

## 5. Seguridad y autenticación

### 5.1 Lo que está bien

| Control | Dónde | Comentario |
|---|---|---|
| CSP estricta sin CDN | `Application::securityHeaders()` (l.210-218) | `default-src 'self'`, `script-src 'self'`, `object-src 'none'`, `frame-ancestors 'none'` |
| Anti-clickjacking, sniffing, referer | ídem | `X-Frame-Options: DENY`, `nosniff`, `Referrer-Policy: same-origin` |
| Cookies de sesión | `Session::start()` l.28-40 | `HttpOnly`, `SameSite=Lax`, `Secure` si `is_https()`, `use_strict_mode`, ruta de sesiones en `storage/` |
| Fijación de sesión | `Auth::attempt` → `Session::regenerate()` | Correcto antes de escribir `user_id` |
| CSRF en todos los POST | `Application::run()` l.47-54 | Token de 32 bytes; 419 con mensaje claro |
| Enumeración de usuarios por tiempo | `Auth::attempt` l.47-50 | `password_verify` contra hash señuelo si el correo no existe |
| Autorización por consulta | `BaseController::project`/`floor` (l.23-41) + 13 consultas con `p.user_id = ?` | No hay IDOR conocido en las rutas auditadas |
| Fotos de evidencia | `Check::detectType()` | Tipo por *magic bytes* (sin GD); se sirve con el tipo guardado |
| Enrutador del escritorio | `tools/desktop/router.php` | Bloquea `app`, `config`, `resources`, `storage`, `tests`, `tools`, `docs` y `paquetes`; también `..` y byte nulo; probado en `tests/php/desktop.mjs` |

### 5.2 Hallazgos

**H-01 · El límite de intentos vive en la sesión, no en la cuenta · P1**
`Auth::attempt()` guarda las marcas de tiempo en `$_SESSION['login_attempts']`. **Consecuencia:** quien borre la cookie reinicia el contador; no hay límite por IP ni por cuenta, ni registro de intentos fallidos para detectar un ataque. **Recomendación:** tabla `login_attempts` (correo, IP, resultado, fecha) con ventana deslizante y bloqueo temporal por cuenta; registrar el evento aunque el acceso sea correcto.

**H-02 · No hay administración de cuentas · P1**
Solo el instalador crea un usuario (`Installer.php`). No hay alta, baja, cambio de rol ni invitación. `users.is_admin` se declara en el esquema y **solo aparece en `User.php` l.13 y l.46**; ninguna consulta ni vista lo lee. **Consecuencia:** rotar personal exige tocar la base a mano; no se puede separar quien dibuja de quien verifica; todas las personas de una misma instalación comparten una única credencial. **Recomendación:** decidir primero el modelo de tenencia (sección 11) y después construir miembros y roles sobre él; mientras tanto, un comando de consola documentado para crear usuarios.

**H-03 · Sin recuperación de contraseña ni correo saliente · P1**
Existe `account/password` para el usuario con sesión, nada más. `grep -c smtp app/` = **0**. **Consecuencia:** una contraseña perdida deja la instalación inaccesible para su dueño; el soporte tendría que editar el `.sqlite`. **Recomendación:** al menos un mecanismo de recuperación local verificable (código de un solo uso impreso al instalar, o comando de consola); si se añade correo, configurarlo opcional y documentar el requisito.

**H-04 · Enlaces de brigada permanentes y sin control de uso · P2**
`Brigade::findByToken()` devuelve el plano si `enabled = 1`. El token es de 32 hex (no adivinable) pero **no caduca**, no tiene límite de peticiones, no registra accesos y no se puede restringir a una red. Se puede desactivar y regenerar a mano desde el panel del piso. **Consecuencia:** un enlace reenviado por WhatsApp sigue sirviendo indefinidamente; si sale de la organización no hay forma de saberlo. **Recomendación:** caducidad configurable, contador de accesos con fecha, y opción de regeneración automática tras N días. Mantener la promesa de que la página no expone la cuenta ni el editor.

**H-05 · `is_admin` es una columna muerta · P2** — ver H-02. Se documenta aparte porque una futura consulta que lo active cambiará el comportamiento sin que exista hoy ninguna prueba que lo cubra. **Recomendación:** eliminarla o implementarla; no dejarla como señal ambigua.

**H-06 · Migraciones que fallan en silencio · P0**
`Database::migrate()` envuelve los pasos 2–5 en `try { … } catch (Throwable) { error_log(...) }`. Se ejecuta **en cada petición** (`Application::run()` l.41) y usa un `static $done` por proceso. **Consecuencia:** si la base está bloqueada, es de solo lectura o el disco está lleno, la aplicación arranca con el esquema anterior y falla más adelante con errores de columna inexistente que no apuntan a la causa; el usuario no ve nada. **Recomendación:** migraciones numeradas en archivos, aplicadas dentro de una transacción, con tabla `schema_migrations`, y **fallo explícito** con página de error y mensaje accionable cuando la migración no se puede completar.

**H-07 · Dependencia de `.htaccess` para ocultar carpetas internas · P1 (según despliegue)**
La protección es de tres capas, y **las tres son de Apache**: `RedirectMatch 404 ^/(app|config|resources|storage|tests|tools|docs)` en la raíz, `Require all denied` en `storage/.htaccess` y `config/.htaccess`, y `index.html` en `storage/` para que un listado de directorio no quede expuesto. Las tres se ignoran en nginx; `Require all denied` es sintaxis de Apache 2.4. El escritorio tiene su enrutador con pruebas (`router.php`) y Android sirve desde un sistema de archivos virtual, así que el riesgo es del **hosting**: quien publique en nginx o con `php -S` sin enrutador dejará `storage/` descendible (base con planos y fotos) y `config/` legible si el servidor no ejecuta PHP en esa ruta. **Recomendación:** llevar la aplicación a un `public/` real o documentar y entregar una configuración de nginx equivalente; añadir una comprobación de arranque que avise si `storage/` es accesible desde la URL.

**H-08 · Sin bitácora de cambios ni de accesos · P2**
Solo `floor_versions.created_by` y `element_checks.checked_by` registran autoría. **Consecuencia:** no se puede responder «quién borró el proyecto», «quién cambió la escala» o «quién regeneró el enlace de brigada», preguntas habituales en una auditoría de seguridad y salud. **Recomendación:** tabla `activity_log` (usuario, entidad, acción, IP, fecha) alimentada desde los controladores; no sustituye a `floor_versions`, la complementa.

**H-09 · Sin HSTS y con `style-src 'unsafe-inline'` · P3**
No se emite `Strict-Transport-Security` (depende del hosting) y la CSP admite estilos en línea, necesarios para los atributos `style` del SVG. **Consecuencia:** riesgo bajo; el producto no tiene formularios de terceros ni contenido remoto. **Recomendación:** documentar la cabecera para el hosting HTTPS y mantener la excepción de estilos acotada.

**H-32 · Credencial de fábrica conocida dentro del APK · P3**
`tools/android/build.mjs:107-108` fija `SEED_EMAIL = 'admin@normia.local'` y `SEED_PASSWORD = 'ClaveSegura2026'` y las siembra en la base que viaja dentro del APK (`php/seed.json`); la contraseña está además publicada en `README.md:739`, `README.md:1043` y `docs/ESCRITORIO.md:214`. El escritorio **no** usa esta cuenta: `launcher.php:411` abre el instalador y el usuario define su propia contraseña. **Consecuencia:** en el APK no hay pantalla de acceso (decisión de 1.15.9), así que la cuenta es inerte en el uso normal; el riesgo es que la base privada del teléfono contiene una credencial conocida si algún día se reactiva el acceso, y que `ESCRITORIO.md:214` diga que la cuenta «aparece en la pantalla de acceso» cuando la aplicación abre sin ella. **Recomendación:** no sembrar cuenta si no se va a usar, o generarla aleatoria al compilar (mostrada una sola vez en `BUILD.txt`); corregir esa frase de la documentación.

---

## 6. Editor CAD: geometría, escalas, historial y persistencia

### 6.1 Cómo está construido

- **Modelo** (`lib/model.js`, 2 077 líneas): lista de elementos con `id`, `type`, `layerId`, geometría en unidades del lienzo (`x`, `y`, `w`, `h`, `points`, `rotation`, `radius`), estilo acotado a la paleta de `DesignValidator::COLORS`, y estado `canvas` (`width`, `height`, `grid`, `unit`, `scale`).
- **Geometría** (`lib/geometry.js`, 574): ajustes, intersecciones, arcos por punto medio, `PlanGrid` en servidor para la rejilla de auditoría y cobertura.
- **Render** (`lib/renderer.js`, 1 488): SVG en cliente; el servidor tiene su propio render (`SvgExporter`) para exportar, imprimir y el modo brigadista.
- **Estado** (`editor/store.js`): versión, `dirty`, borrador, llamadas a `api/floors/{id}/save|autosave|discard-draft|versions|restore|settings`.
- **Validación**: el cliente valida para dar mensajes, **el servidor vuelve a validar todo** en `DesignValidator::normalizeArray` antes de escribir. Correcto y defendido.

### 6.2 Hallazgos

**H-10 · El plano exportado no tiene escala física · P1 (P0 para uso dimensionado)**
Tres piezas encadenadas:
1. `canvas.scale` (p. ej. `1:100`) se guarda y se muestra, pero **es solo referencia de impresión**.
2. `MepCalculator::unitsToMeters(string $unit, string $scale = '1:100')` **recibe `$scale` y no lo usa**: devuelve 1,0 / 0,01 / 0,001 según la unidad declarada (`m`, `cm` por defecto, `mm`).
3. `SvgExporter::render()` emite un SVG con `width`/`height` numéricos sin sufijo de unidad y `viewBox="0 0 w h"` en las mismas unidades del lienzo (`SvgExporter.php:37-40`); el `<desc>` de la línea 40 advierte que «las dimensiones y la escala deben verificarse en sitio».

**Consecuencia:** las medidas **internas** son coherentes entre sí (todo se calcula en la unidad del lienzo, incluido el auditor y la cobertura), pero el archivo exportado **no se puede medir con escalímetro** ni insertar en un plano a escala; quien imprima «a 1:100» obtendrá una escala distinta. **Recomendación:** añadir al SVG `width="…mm" height="…mm"` derivados de `unidad × factor de escala`, declarar el factor en el pie y añadir una prueba que compare una cota conocida con su longitud impresa. Mientras no exista, el producto debe seguir diciéndolo con la misma claridad con que lo dice hoy.

**H-11 · Historial de edición en memoria · P2**
`model.js` l.172-712: pila de *snapshots* con `historyLimit = 80`; se pierde al recargar y `replaceDesign` la limpia. **Consecuencia:** un cierre accidental de pestaña deja al usuario sin deshacer, aunque conserva el borrador automático. **Recomendación:** aceptable mientras el borrador cubra el caso; conviene que la interfaz diga «el historial de deshacer se pierde al recargar» en la ayuda del editor.

**H-12 · Autosave sin cola ni reintento · P2**
El guardado automático dispara cada ≥10 s (30 s por defecto) y, si falla, deja el estado «Borrador no guardado» (`editor.js::onAutosaveError`) sin reintentar. Los 409 sí están bien tratados (aviso con recarga o descarga). **Consecuencia:** en una red inestable se acumula trabajo sin persistir; el usuario debe mirar el indicador. **Recomendación:** reintento con espera creciente y aviso persistente no descartable cuando el último intento falló.

**H-13 · Versiones sin poda · P1**
Ver 4.3. **Consecuencia:** crecimiento lineal con cada guardado, sin aviso; el respaldo manual (copiar el `.sqlite`) se vuelve lento, y en el APK el almacenamiento del navegador tiene cuota. **Recomendación:** conservar todas las versiones de los últimos N días y una por día más antigua (o las marcadas), con poda automática y política visible en la interfaz.

**H-14 · `restoreVersion` no comprueba el resultado del UPDATE · P1**
`Floor::restoreVersion()` l.178-186 ejecuta `UPDATE … WHERE id = ? AND version = ?` y **no mira `rowCount()`**; a continuación inserta la versión restaurada. **Consecuencia:** ante una carrera (dos pestañas restaurando), la actualización no ocurre pero **sí se inserta una versión** en `floor_versions` que nunca estuvo vigente; el historial miente y retorna un número de versión falso. **Recomendación:** replicar el patrón de `saveDesign` (si `rowCount() !== 1`, `VersionConflictException`) y añadir una prueba de restauración concurrente.

**H-15 · Zonas horarias mezcladas en la misma respuesta · P2**
`Floor::saveDesign` devuelve `saved_at => date('Y-m-d H:i:s')` (hora local del servidor) mientras las columnas usan `CURRENT_TIMESTAMP` (UTC) y `VerificationController` interpreta `checked_at` como UTC (`strtotime($row . ' UTC')`). **Consecuencia:** la etiqueta «guardado a las 15:04» puede no coincidir con la fecha mostrada tras recargar; los cálculos de «vencido» dependen de la zona del servidor. **Recomendación:** una sola convención (UTC en la base, presentación en hora local) y una función única de formato.

**H-16 · Un solo borrador por piso, sin autor · P2**
`draft_json`/`draft_base_version`/`draft_updated_at` son únicos por fila. **Consecuencia:** con varias personas por piso (el escenario que habilita la multiempresa), el segundo sobrescribe el borrador del primero sin verlo; el 409 solo protege el guardado manual. **Recomendación:** convertir el borrador en tabla con autor y fecha (`drafts(floor_id, user_id, …)`) antes de abrir la aplicación a equipos.

**H-17 · Los límites duros se descubren al guardar · P2**
`MAX_ELEMENTS = 1200`, `MAX_LAYERS = 24`, `MAX_GROUPS = 80`, `MAX_POINTS = 40`, etiquetas ≤240 caracteres y ≤6 líneas, coordenadas 0–10 000, opacidad 0,1–1, trazo 0–40. El cliente no anticipa el tope. **Consecuencia:** en un plano grande el trabajo se pierde al guardar, con el mensaje del servidor. **Recomendación:** indicador de capacidad en el editor (elementos usados / tope) y bloqueo de la acción que excede.

**H-18 · Cuerpo JSON sobredimensionado devuelve vacío · P2**
`Request::json()` l.94: si el cuerpo supera 2 500 000 bytes **devuelve `[]` en silencio**. **Consecuencia:** el guardado falla con «El diseño no es válido» en lugar de explicar el tamaño. **Recomendación:** responder 413 con mensaje explícito y sugerir exportar/limpiar.

---

## 7. Operación: migraciones, errores, logs, respaldos y pruebas

**H-19 · Sin respaldo automático ni verificación de integridad · P0**
Documentado en `README.md:190` como procedimiento manual (copiar `config/config.php` + `storage/normia-*.sqlite` con `-wal`/`-shm`, o `sqlite3 .backup`). No hay tarea programada, ni copia de seguridad desde la interfaz, ni `PRAGMA integrity_check` en ningún punto. **Consecuencia:** un disco dañado, un borrado accidental o un archivo copiado en caliente sin el `-wal` **pierden todos los planos, versiones y fotos**. Es el P0 con mayor impacto directo sobre el cliente. **Recomendación:** botón «Crear copia de seguridad» que use la API de respaldo de SQLite y descargue un `.sqlite` consistente; recordatorio periódico; `integrity_check` al arrancar; documentar la restauración paso a paso.

**H-20 · Logs mínimos, sin rotación ni nivel · P2**
`error_log()` más `storage/last-error.log`, **sobrescrito en cada error** (`Application.php:87-88`). Llamativo: `Paths::logs()` existe, devuelve `storage/logs` y la carpeta **se crea y se mantiene vacía** (`Paths::ensure()`), porque nadie escribe en ella. **Consecuencia:** tras dos fallos seguidos solo queda el último; el usuario final no ve nada y el soporte no tiene traza. **Recomendación:** usar `Paths::logs()` con un archivo por mes (`app-AAAA-MM.log`), rotación simple y un visor de diagnóstico para el administrador.

**H-21 · Pruebas: mucha cobertura de lo construido, ninguna de lo frágil · P2**
Las suites miden bien el comportamiento actual (15 pasos; 310 funcionales; 383 del editor; 50 de páginas; 124 offline), y la de escritorio prueba el enrutador de archivos. **No cubren:** concurrencia sobre la misma base, restauración de versión en carrera, migración fallida, crecimiento de `floor_versions`, ni equivalencia entre el SVG del cliente y el del servidor. **Recomendación:** cinco pruebas nuevas con esos nombres; son baratas y cubren los P1 anteriores.

**Estado de las suites.** Las cifras anteriores corresponden a la ejecución de la entrega 1.16.0. Esta auditoría **no volvió a ejecutarlas** (habría reescrito paquetes de `dist/`), por lo que se citan como registro del proyecto, no como comprobación de hoy.

---

## 8. Preparación para la plataforma ampliada

Pregunta de fondo: **¿qué hay que cambiar para que la aplicación deje de ser «mis planos» y pase a ser «los planos de la empresa, sus sedes, sus brigadas y sus hallazgos»?**

| Capacidad pedida | Qué existe hoy | Qué falta en el modelo | Coste |
|---|---|---|---|
| **Multiempresa** (H-27) | Nada. `projects.user_id` es la única frontera | `organizations`, `memberships(user, org, role)`, y cambiar la frontera de `user_id` a `organization_id` en `projects` y todas las consultas | **Alto**: toca 13 consultas, el instalador, las exportaciones y las pruebas funcionales |
| **Sedes** | `projects.site` y `projects.workplace` como texto libre | `sites` (organización, nombre, dirección, ciudad, responsable) y `projects.site_id` | **Medio**: migración de datos por texto, con tabla de equivalencias |
| **Recursos inventariables** (H-31) | Objetos CAD (`cad_fire_ext_*`, etc.) dentro del JSON | `assets` (tipo, serie, sede, ubicación, vencimiento, proveedor, estado) + relación opcional `element_id` con el dibujo | **Alto**: es un dominio nuevo, no una pantalla |
| **Brigadas** | `brigade_links`: un enlace de solo lectura por piso | `brigades`, `brigade_members` con cargo, vigencia y capacitación | **Medio**: el enlace actual se conserva como vista pública |
| **Incidentes** | Nada | `incidents` (fecha, sede, tipo, severidad, descripción, plano y elemento) | **Medio**: se apoya en `floor_id` + `element_id` |
| **Acciones correctivas** | Solo `element_checks.status = 'issue'` con nota | `actions` (origen: verificación o incidente, responsable, plazo, estado, evidencia de cierre, verificación de eficacia) | **Medio-alto**: es el corazón del sistema de gestión (H-22) |
| **Gestión química** | Nada | `chemicals` (nombre, CAS, proveedor, cantidad, ubicación), ficha de seguridad adjunta, compatibilidad de almacenamiento | **Alto**: exige almacenamiento de documentos y reglas de compatibilidad |

**H-27 · No existe la entidad organización · P1**
No hay `organizations` ni ninguna tabla equivalente; `tenant` y `multiempresa` no aparecen en `app/`, y la única aparición de `organization` en `assets/` es la sección «Capa» del inspector (`editor/inspector.js:811,849`), no una entidad. La frontera de datos es `projects.user_id`. **Consecuencia:** dos empresas exigen **dos instalaciones completas** (dos bases, dos configuraciones, dos respaldos) y un usuario no puede ver los planos de su empresa desde otra instalación. **Recomendación:** es el primer trabajo del roadmap; ver sección 11, punto 1.

**H-30 · Sin licenciamiento, activación ni actualizaciones · P2 (comercial)**
No hay verificación de licencia, ni canal de actualización, ni versión de instalación registrada más allá de `NORMA_VERSION` en el código. **Consecuencia:** hoy el producto se distribuye como paquete completo sin control de versión del cliente; dar soporte a una instalación concreta exige preguntar qué ZIP descargó. **Recomendación:** registrar la versión con la que se instaló cada base (`app_meta`) y mostrar un diagnóstico exportable; el licenciamiento, después y solo si el modelo comercial lo requiere.

**H-31 · Los recursos del plano no son activos · P1**
Un extintor es un elemento de `design_json` con agente y capacidad; no tiene serie, fecha de recarga, proveedor ni vencimiento. `asset_id`, `numero_serie` y `mantenimiento` no aparecen en `app/`; «inventario» existe solo como «inventario verificable del plano» (`VerificationInventory`), que cuenta elementos dibujados, no activos. **Consecuencia:** la cobertura de extintores es geometría correcta sobre objetos anónimos; no se puede cruzar el plano con el inventario real ni avisar de una recarga vencida (ver sección 11, punto 5). **Recomendación:** tabla `assets` y relación opcional con `element_id`, reutilizando `element_checks` para la verificación.

**H-22 · La novedad no se convierte en acción · P1**
`element_checks.status = 'issue'` guarda una observación con foto. **No hay** responsable, plazo, acción, cierre ni verificación de eficacia: `grep` de `incidente` o `correctiva` en `app/` y `assets/` = **0** (las coincidencias de «capa» son las capas del dibujo). **Consecuencia:** el módulo de verificación produce **evidencia de inspección**, no gestión; el ciclo se cierra fuera de la aplicación, en una hoja de cálculo. Es el hueco funcional más grande respecto de lo que el producto promete sugerir. **Recomendación:** tabla `actions` con origen polimórfico (`element_check`, `incident`), responsable, fecha límite, estado y cierre con evidencia; vista de «acciones abiertas» por sede y por responsable. **Es el segundo trabajo después de la tenencia.**

**H-23 · Sin notificaciones ni recordatorios · P2**
`floors.check_days` (30 por defecto) solo alimenta el filtro «vencidos» de la página de verificación (`VerificationController:28`, `VerificationInventory::coverage`). No hay correo, ni tarea programada, ni aviso al entrar. **Consecuencia:** un plan que debía verificarse cada 30 días se queda sin verificar sin que nadie lo sepa. **Recomendación:** un panel de vencimientos en el inicio (sin correo) como primer paso; el correo, después y opcional.

**H-24 · Los complementos solo aportan catálogo · P3**
`PluginManager` valida y normaliza señales y objetos CAD; no admite campos, validaciones ni rutas. **Consecuencia:** bien acotado para seguridad (no hay ejecución de código de terceros, que es lo correcto), pero no sirve como mecanismo de extensión funcional. **Recomendación:** mantenerlo así y decirlo en `docs/PLUGINS.md` con la misma claridad; si algún día se amplía, hacerlo por declaración de datos, nunca por código.

**H-25 · `BrigadeController` duplica la lista de extintores · P3**
`BrigadeController::EXTINGUISHERS` (l.23-26) fija cuatro códigos `cad_fire_ext_*` / `cad_eds_*` / `cad_drg_*`, mientras `ExtinguisherNorms::isExtinguisher()` decide por `catalogDefaults` **y** por el campo `extAgent`. Hoy ambas listas coinciden exactamente (`catalogDefaults` tiene los mismos cuatro). **Consecuencia:** en cuanto un complemento añada un extintor, el cálculo de cobertura lo contará y los grupos del modo brigadista no. **Recomendación:** usar `ExtinguisherNorms::isExtinguisher()` en el controlador.

**H-26 · Sin exportación de inventario ni pliego · P2**
No hay CSV de señalización ni de equipos (rutas `…/signage` y `…/signage.csv` no existen en `Application::router()`). **Consecuencia:** el instalador compra señalización contando a mano; es el bloque 6 del issue #6, pendiente de rehacer. **Recomendación:** retomarlo después de H-10 (escala) para que el pliego pueda citar medidas.

---

## 9. Matriz de prioridades

Criterio: **P0** = pérdida o exposición grave del dato, o bloqueo total del cliente; **P1** = impide operar con garantías o bloquea la ampliación; **P2** = importante, con solución conocida; **P3** = mejora.

| ID | Título | Sev. | Área | Impacto | Esfuerzo | Depende de |
|---|---|---|---|---|---|---|
| H-06 | Migraciones silenciosas, sin transacción ni versión | **P0** | Datos | Alto | Bajo | — |
| H-19 | Sin respaldo automático ni `integrity_check` | **P0** | Operación | Alto | Bajo-medio | — |
| H-01 | Límite de intentos en sesión | P1 | Seguridad | Medio | Bajo | — |
| H-02 | Sin administración de cuentas ni roles | P1 | Seguridad | Alto | Alto | H-27 (tenencia) |
| H-03 | Sin recuperación de contraseña | P1 | Seguridad | Alto | Bajo-medio | — |
| H-07 | Dependencia de `.htaccess` según despliegue | P1 | Seguridad | Alto (si nginx) | Medio | — |
| H-10 | SVG sin escala física | P1 | Editor | Alto | Medio | — |
| H-13 | `floor_versions` sin poda | P1 | Datos | Alto | Bajo | H-19 |
| H-14 | `restoreVersion` sin `rowCount` | P1 | Datos | Medio | **Muy bajo** | — |
| H-22 | La novedad no genera acción correctiva | P1 | Producto | Alto | Medio-alto | H-27 |
| H-04 | Enlaces de brigada sin caducidad | P2 | Seguridad | Medio | Bajo | H-08 |
| H-08 | Sin bitácora de cambios y accesos | P2 | Seguridad | Medio | Medio | — |
| H-11 | Historial de edición en memoria | P2 | Editor | Bajo-medio | Bajo (documentar) | — |
| H-12 | Autosave sin reintento | P2 | Editor | Medio | Bajo | — |
| H-15 | Zonas horarias mezcladas | P2 | Datos | Bajo-medio | Bajo | — |
| H-16 | Un borrador por piso | P2 | Editor | Medio (futuro) | Medio | H-27 |
| H-17 | Límites duros no anticipados | P2 | Editor | Medio | Bajo | — |
| H-18 | JSON sobredimensionado devuelve vacío | P2 | Editor | Bajo | Muy bajo | — |
| H-20 | Logs sobrescritos | P2 | Operación | Medio | Bajo | — |
| H-21 | Pruebas sin concurrencia ni migración | P2 | Calidad | Medio | Medio | H-06, H-14 |
| H-23 | Sin recordatorios de verificación | P2 | Producto | Medio | Medio | H-08 |
| H-26 | Sin pliego de señalización (issue #6) | P2 | Producto | Medio | Bajo-medio | H-10 |
| H-05 | `is_admin` muerta | P3 | Seguridad | Bajo | Trivial | H-02 |
| H-09 | Sin HSTS / estilos en línea | P3 | Seguridad | Bajo | Bajo | — |
| H-32 | Credencial de fábrica dentro del APK | P3 | Seguridad | Bajo | Bajo | — |
| H-24 | Complementos solo de catálogo | P3 | Arquitectura | Bajo | — | — |
| H-25 | Lista de extintores duplicada | P3 | Arquitectura | Bajo | Trivial | — |
| H-27 | Sin `organizations`/`memberships` | P1* | Producto | Alto | Alto | H-02 |
| H-28 | `element_id` sin FK y sin exportación de historial | P3 | Datos | Bajo | Bajo | — |
| H-29 | `SvgExporter` y `renderer.js` sin prueba de equivalencia | P3 | Calidad | Bajo | Medio | — |
| H-30 | Sin licenciamiento ni actualizaciones | P2* | Comercial | Alto | Alto | H-27 |
| H-31 | Sin inventario de recursos (activos) | P1* | Producto | Alto | Alto | H-27 |

\* Hallazgos de preparación (sección 8): no son defectos de 1.16.0, son condiciones para ampliar. Se priorizan como P1/P2 porque el resto del roadmap depende de ellos.

---

## 10. Roadmap

Los cuatro ejes pedidos se reparten así: **estabilización** en la fase 0, **evolución funcional** en las fases 1 y 3, **arquitectura** en la fase 2 —que es la que habilita todo lo demás— y **preparación comercial** en la fase 4. Las duraciones son relativas y suponen una persona con dedicación completa; sirven para ordenar, no para prometer fechas.

### Fase 0 · Estabilización · integridad y confianza (2–3 semanas) — **antes de cualquier función nueva**
Objetivo: que nadie pierda un plano.
1. H-19 respaldo consistente desde la interfaz + `integrity_check` + guía de restauración.
2. H-06 migraciones versionadas, transaccionales y con fallo visible.
3. H-14 `restoreVersion` con `rowCount`; H-13 poda de versiones; H-15 una sola zona horaria.
4. H-20 logs por mes; H-21 las cinco pruebas nuevas (concurrencia, restauración en carrera, migración fallida, poda de versiones, equivalencia SVG).
**Cierre:** un plano no se puede perder por un fallo de disco, un error de migración o dos pestañas; y hay una prueba que lo demuestra.

### Fase 1 · Evolución funcional I · del dibujo al documento técnico (4–6 semanas)
1. H-10 escala física real en el SVG y en el PDF de impresión, con prueba de cota conocida.
2. H-26 pliego de señalización (issue #6, bloque 6) con cantidades y precios.
3. H-18 y H-17 mensajes y capacidad en el editor; H-12 reintento de autosave.
**Cierre:** un plano exportado se imprime, se mide y se compra con él.

### Fase 2 · Arquitectura · identidad y tenencia (6–8 semanas) — **la bisagra**
1. H-27 `organizations` + `memberships` + roles (`propietario`, `editor`, `verificador`, `lector`); migración de `projects.user_id` conservando los datos.
2. H-02 alta/baja de miembros e invitaciones; H-03 recuperación de contraseña; H-01 intentos en base; H-05 decidir `is_admin`.
3. H-08 bitácora de actividad; H-16 borradores por usuario.
4. Sedes: `sites` y conversión de `projects.site/workplace` con tabla de equivalencias.
**Cierre:** dos empresas en la misma instalación no se ven entre sí, y eso está probado.

### Fase 3 · Evolución funcional II · sistema de gestión sobre el plano (8–12 semanas)
1. H-22 acciones correctivas (origen en verificación o incidente, responsable, plazo, cierre, eficacia).
2. Incidentes; H-23 recordatorios y panel de vencimientos.
3. H-31 inventario de recursos con serie, vencimiento y mantenimiento; enlace opcional con el elemento dibujado.
4. Brigadas como entidad (integrantes, cargos, vigencia) reutilizando el enlace público actual.
5. Gestión química: inventario, ficha de seguridad adjunta, compatibilidad de almacenamiento.
**Cierre:** una novedad de inspección termina en una acción cerrada con evidencia, sin salir de la aplicación.

### Fase 4 · Preparación comercial
Licenciamiento y activación (H-30), canal de actualizaciones, soporte con diagnóstico exportable, guía de despliegue por tipo de hosting (H-07), política de datos y conservación, y revisión legal **externa** de los textos normativos —la aplicación nunca debe afirmar cumplimiento.

---

## 11. Los cinco problemas que hay que resolver antes de ampliar

### 1. No hay modelo de tenencia, solo un dueño por fila
**Por qué bloquea:** `projects.user_id` es a la vez la frontera de seguridad y el modelo de negocio. Sin `organizations`/`memberships`, cada módulo nuevo (sedes, brigadas, incidentes, química) tendría que inventar su propio mecanismo de propiedad, y migrarlos después costaría más que hacerlo ahora.
**Qué falta:** dos tablas, roles, y reemplazar la frontera en las 13 consultas y en las pruebas.
**Resuelto cuando:** una prueba funcional crea dos organizaciones, dos usuarios y demuestra que ninguno alcanza datos del otro por ninguna ruta, incluidas exportaciones, fotos y enlaces de brigada.

### 2. Una novedad no se convierte en acción
**Por qué bloquea:** es la diferencia entre «registré una observación» y «gestioné el riesgo». Todo el valor del sistema de gestión —y de la conversación comercial— está en el ciclo hallazgo → responsable → plazo → cierre → eficacia, y hoy vive fuera de la aplicación.
**Qué falta:** tabla `actions` con origen polimórfico, responsable, plazo, estados y evidencia de cierre; vista por sede y por responsable.
**Resuelto cuando:** una verificación con `issue` puede generar una acción, asignarse, cerrarse con foto y aparecer en un listado de acciones abiertas.

### 3. El plano no es un documento a escala
**Por qué bloquea:** el producto se llama «Planos CAD» y exporta un SVG sin tamaño físico. Las medidas internas son coherentes, pero el archivo no sirve para medir, insertar en un plano mayor ni comprobar un recorrido con escalímetro. Un plano de evacuación sin escala verificable es una lámina ilustrativa.
**Qué falta:** derivar del lienzo un tamaño en milímetros, declararlo en el SVG y el pie, y probar que una cota conocida mide lo que dice.
**Resuelto cuando:** una prueba toma un muro de 5 m en un lienzo `1:100` y comprueba 50 mm en el SVG resultante.

### 4. La persistencia no está gobernada
**Por qué bloquea:** versiones sin poda, respaldos manuales, migraciones que fallan en silencio, restauración sin verificación de resultado y logs que se sobrescriben. Con un cliente y cien planos se aguanta; con diez clientes es una incidencia garantizada, y sin bitácora no se puede reconstruir qué pasó.
**Qué falta:** respaldo consistente, migraciones versionadas y transaccionales, poda con política, bitácora de actividad y logs rotados.
**Resuelto cuando:** se puede restaurar una copia y demostrar que el historial de versiones y la bitácora coinciden con lo que ocurrió.

### 5. Los recursos del plano no son activos
**Por qué bloquea:** un extintor dibujado no tiene número de serie, fecha de recarga, proveedor ni vencimiento; un equipo de emergencia no tiene mantenimiento. Sin esa capa, la cobertura de extintores es geometría correcta sobre objetos anónimos, y no se pueden cruzar brigadas, incidentes ni inventario químico con el plano.
**Qué falta:** `assets` con tipo, serie, sede, ubicación, vencimiento y estado; relación opcional con `element_id`; vencimientos en el panel de inicio.
**Resuelto cuando:** el extintor del dibujo y el extintor del inventario son el mismo registro, y su vencimiento aparece en la lista de pendientes.

---

## Anexo A · Evidencia reproducible

Comandos de solo lectura usados para esta auditoría (desde la raíz del repositorio):

```bash
# Volumen y reparto
find . -path ./node_modules -prune -o -name '*.php' -print | wc -l      # 80
find assets -name '*.js' | wc -l                                        # 23
wc -l $(find assets/js -name '*.js') | tail -1                          # 11851
wc -l app/Services/*.php | tail -1                                      # 7246

# Ausencias de concepto (solo .php y .js; el favicon SVG lleva base64)
grep -rn "incidente\|correctiva" app/ assets/ --include=*.php --include=*.js   # 0
grep -rn "quimic\|MSDS"          app/ assets/ --include=*.php --include=*.js   # 0
grep -rn "mantenimiento\|numero_serie\|asset_id" app/ assets/ --include=*.php --include=*.js  # 0
grep -rn "smtp"                   app/ assets/ --include=*.php --include=*.js   # 0
grep -rn "tenant\|multiempresa"   app/ --include=*.php                        # 0

# Conceptos que sí existen pero en otro sentido (no confundir)
grep -rn "organization" assets/js/editor/inspector.js     # sección «Capa»
grep -rin "inventario" app/                               # inventario verificable del plano
grep -rin "sustancia" app/                                # etiqueta de plantilla de complemento

# Esquema y migraciones
grep -n "PRAGMA user_version" app/Core/Database.php
sed -n '/function migrate/,/^    }/p' app/Core/Database.php

# Escala
grep -n -A8 "function unitsToMeters" app/Services/MepCalculator.php
```

Vista previa (solo lectura, puerto 8080): `/index.php?r=plugins` → 200 con «Todavía no hay complementos»; `/index.php?r=plugins/manual` → 200; `/index.php?r=plugins/plantilla/cad` → `application/json` con `Content-Disposition: attachment`.

> La vista previa mantiene **una sesión ya autenticada** en el propio servidor (`tools/preview-server.mjs:119` hace `runtime.login(...)` una vez), por eso las peticiones con `curl` ven páginas privadas. No es un fallo de autorización: es el diseño del servidor de vista previa.

---

## Anexo B · Lo que no se pudo verificar

Se declara explícitamente para no confundirlo con lo comprobado:

1. **Corrección numérica** de `PlanAudit` (rejilla, camino más corto, ocupación), `ExtinguisherCoverage` y `MepCalculator` contra casos con resultado conocido. Se leyó el código; no se contrastó con un plano medido a mano.
2. **Profundidad del saneado SVG** de `LibraryRepository::safeSvg` frente a un SVG malicioso elaborado (se leyó la lista de comprobaciones; no se hizo *fuzzing*).
3. **Concurrencia real de SQLite** con dos o más sesiones escribiendo a la vez (`SQLITE_BUSY`, pérdida de actualizaciones, comportamiento de `BEGIN` diferido en WAL).
4. **Comportamiento en escritorio y APK** de un plano que usa un complemento ya borrado (elemento huérfano en `design_json`).
5. **Rendimiento** con 1 200 elementos: tiempo de render, de validación y de auditoría no medidos.
6. **Accesibilidad** de la interfaz (teclado, lectores de pantalla) y contraste: no evaluada.
7. **Suites reejecutadas**: las cifras citadas provienen de la entrega 1.16.0; esta auditoría no las volvió a correr ni reconstruyó paquetes.
8. **Despliegue en nginx**: no se probó; el riesgo de H-07 es una inferencia del contenido de `.htaccess`, no una comprobación en ese servidor.

---

*Documento de auditoría de solo lectura. No modifica código, base de datos ni paquetes. Las referencias normativas citadas en el producto (NTC 2885, NFPA 10, Resolución 2400 de 1979) son umbrales de referencia configurables y no constituyen un dictamen de cumplimiento.*
