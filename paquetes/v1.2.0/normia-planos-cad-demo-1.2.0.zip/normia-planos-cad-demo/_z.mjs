import fs from 'node:fs';
import { Resvg } from '@resvg/resvg-js';
const cat = JSON.parse(fs.readFileSync('resources/cad-objects.json','utf8'));
const keys = process.argv.slice(2);
const cols=4, cw=180, ch=190, rows=Math.ceil(keys.length/cols);
const W=cols*cw, H=rows*ch;
let out=`<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}"><rect width="${W}" height="${H}" fill="#fff"/>`;
keys.forEach((k,i)=>{
  const o=cat.objects[k]; const x=(i%cols)*cw, y=Math.floor(i/cols)*ch;
  out+=`<rect x="${x+8}" y="${y+8}" width="${cw-16}" height="${ch-16}" fill="#f8fafc" stroke="#e2e8f0"/>`;
  const body=o.svg.replace(/^<svg[^>]*>/,'').replace(/<\/svg>$/,'');
  out+=`<g transform="translate(${x+30} ${y+20}) scale(1.2)" fill="none" stroke="${o.color}" color="${o.color}">${body}</g>`;
  out+=`<text x="${x+cw/2}" y="${y+ch-30}" text-anchor="middle" font-family="Helvetica" font-size="10" fill="#334155">${o.name}</text>`;
  out+=`<text x="${x+cw/2}" y="${y+ch-16}" text-anchor="middle" font-family="Helvetica" font-size="8" fill="#94a3b8">${k}</text>`;
});
out+='</svg>';
fs.writeFileSync('/tmp/z.png', new Resvg(out,{fitTo:{mode:'width',value:Math.round(W*1.8)}}).render().asPng());
